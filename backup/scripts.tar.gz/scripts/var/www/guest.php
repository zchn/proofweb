<html><body><form action='/logged.html' method='post' name='frm'>
<input name="login" value="nobody" type="hidden">
<input name="pass" value="anon" type="hidden">
<input name="logingrp" value="nogroup/" type="hidden">
</form>
<script language="JavaScript">
document.frm.submit();
</script>
</body></html>
