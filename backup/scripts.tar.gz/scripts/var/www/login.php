Sample ProofWeb Login page. Adjust.

<form action="guest.php" method="get">
<table>
<tr><td align="center"><input value="Guest login" type="submit"/></td></tr>
</table>
</form>
</li>

<li>
<form action="course.php" method="get">
<table>
<tr>
<td align="right" width="60">Course:</td>
<td align="left">
<select name="course">
<option value=""></option>
<option value="samplecourse">Course name</option>
</select>
</td>
<td width="60"></td>
</tr>
<tr><td></td><td align="center"><input value="Student login" type="submit"/></td></tr>
</table>
</form>
</li>
</ul>
<ul>
